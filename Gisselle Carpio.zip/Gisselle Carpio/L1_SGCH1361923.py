'''variable1 = 21000 # 
print("comentario")

print(type(variable1), end="")

variable1="Hola"
print(variable1)
print(type(variable1))

variable2= 123.1
print(variable2)
print(type(variable2))

variable3 = False
print(variable3)
print(type(variable3))'''


#print("Hola mundo soy Gisselle")

'''print("Hola mundo")
print("Soy Gisselle")
#el print sin end nos escribira el texto en diferente linea

print("Hola mundo", end="")
print(" soy Gisselle", end="")
#el print con end nos continuara el texto en la misma linea'''

'''texto = input()
print(texto + " Hola")'''


texto = input()
print("Hola Mundo", end="")
print(" soy " + texto)